<?php get_header(); ?>
<div class="container-fluid shop-page">
<?php woocommerce_content(); ?>

</div>
<?php get_footer(); ?>